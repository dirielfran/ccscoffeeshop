import { Component } from '@angular/core';

@Component({
    templateUrl: './error2.component.html'
})
export class Error2Component {

}
