import { Component } from '@angular/core';

@Component({
    templateUrl: './forgotpassword.component.html',
})
export class ForgotPasswordComponent {}
