import { Component } from '@angular/core';

@Component({
    templateUrl: './login2.component.html',
})
export class Login2Component {
    rememberMe: boolean = false;
}
