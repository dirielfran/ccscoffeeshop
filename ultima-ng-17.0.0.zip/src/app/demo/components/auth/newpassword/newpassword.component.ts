import { Component } from '@angular/core';

@Component({
    selector: 'app-newpassword',
    templateUrl: './newpassword.component.html',
})
export class NewPasswordComponent { }
