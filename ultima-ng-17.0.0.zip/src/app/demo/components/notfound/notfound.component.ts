import { Component } from '@angular/core';

@Component({
	templateUrl: './notfound.component.html'
})
export class NotfoundComponent { }