import { Component } from '@angular/core';

@Component({
	templateUrl: './notfound2.component.html'
})
export class Notfound2Component { }